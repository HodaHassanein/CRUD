let titel =document.getElementById("titel") 
let count =document.getElementById("count")
let category =document.getElementById("category")
let price =document.getElementById("price")
let ads =document.getElementById("ads")
let taxes =document.getElementById("taxes")
let discount =document.getElementById("discount")
let create =document.getElementById("create")
let total =document.getElementById('total')
let mood ='create'
let temp ;
function get_tot(){
    if(price.value !=''){
        let reaslet =+price.value + +ads.value + +taxes.value - +discount.value
    total.innerHTML = reaslet
    total.style.backgroundColor ='red';
    }       
}
let new_pro_arr;
if(localStorage.pro != null){
    new_pro_arr=JSON.parse(localStorage.pro) 
}else{
     new_pro_arr =[]
}

create.onclick =function(){

 let new_pro = {
    titel:titel.value,
    count:count.value,
    category:category.value,
    price:price.value,
    ads:ads.value,
    taxes:taxes.value,
    discount:discount.value,
    total:total,
}
if(titel.value =='' ){
   
    alert("please enter titel ")
}else if(price.value =='' ){
    alert("please enter price ")
}else if( category.value ==''){
    alert("please enter category ")
}else if(count.value ==''){
    alert("please enter count ")
}else{
    
    if(mood=='create'){ new_pro_arr .push(new_pro) 
        localStorage.setItem('pro',  JSON.stringify( new_pro_arr))
        cleardata()
        showdata()
    }else{
        new_pro_arr[temp]=new_pro 
        console.log(new_pro_arr[temp])
        console.log(new_pro)
        localStorage.setItem('pro',  JSON.stringify( new_pro_arr))
        cleardata()
        mood='create'
        create.innerHTML=`create`
        showdata()
    }
   console.log(new_pro_arr)
}}

function cleardata(){
   titel.value='',
   count.value='',
    category.value='',
    price.value='',
    ads.value='',
    taxes.value='',
    discount.value='',
    total.innerHTML=''
}
function showdata(){
    
let tabel='';
    for (let index = 1; index < new_pro_arr.length; index++) {
       
        tabel+= `
        <tr>
      <td>${index}</td>
      <td>${new_pro_arr[index].titel}</td>
      <td>${new_pro_arr[index].count}</td>
      <td>${new_pro_arr[index].category}</td>
      <td>${new_pro_arr[index].price}</td>
      <td>${new_pro_arr[index].ads}</td>
      <td>${new_pro_arr[index].taxes}</td>
      <td>${new_pro_arr[index].discount}</td>
      <td><button onclick="add(${index})" id="add">ADD </button></td>
      <td><button onclick="sal(${index})" id="sale">sale </button></td>
      <td><button onclick=" ubdate(${index})" " id="ubdate">ubdate </button></td>
      <td><button onclick=" del(${index})" " id="del">delete </button></td>
      <td>${+new_pro_arr[index].price+ +new_pro_arr[index].ads+ +new_pro_arr[index].taxes - +new_pro_arr[index].discount}</td>
      </tr>
    `
 
    }

    document.getElementById('tb').innerHTML=  tabel
    if(new_pro_arr.length!=0){
        let deleteall=document.getElementById('da')
        deleteall.innerHTML=`<button onclick="dele()" >DELETE ALL item </button>`
    }
    else{
        deleteall.innerHTML=''
 
    }
}

showdata()

function sal(index){
    if (new_pro_arr[index].count<=1) {
    
        new_pro_arr.splice(index,1)
        localStorage.setItem('pro',  JSON.stringify( new_pro_arr))
    
      showdata()
    }else{
        (new_pro_arr[index].count= new_pro_arr[index].count -1 )
        localStorage.setItem('pro',  JSON.stringify( new_pro_arr))
        showdata()
    }

    
} 

function add(index){
    
    
        (new_pro_arr[index].count=  +new_pro_arr[index].count +1 )
        localStorage.setItem('pro',  JSON.stringify( new_pro_arr))
        showdata()
   

    
} 

function dele(){
  console.log("kgbfhjd")
    localStorage.clear()
    new_pro_arr.splice(0)
      showdata()
    
}


function ubdate(index){
    
    titel.value=new_pro_arr[index].titel
    count.value=new_pro_arr[index].count
    category.value=new_pro_arr[index].category
    price.value=new_pro_arr[index].price
    ads.value=new_pro_arr[index].ads
    taxes.value=new_pro_arr[index].taxes
    discount.value=new_pro_arr[index].discount
    get_tot()
    mood='ubdate'
    create.innerHTML=`ubdate`
    temp=index;
}
function del(index){
    new_pro_arr.splice(index,1)
    localStorage.setItem('pro',  JSON.stringify( new_pro_arr))
    
      showdata()
}
 let s_m ='titel'

function s_mood(id){
    if (id=='saerch_c') {
        s_m ='category'
        saerch.placeholder="saerch by category"
    }else{
        saerch.placeholder="saerch by titel"
    }

    
}
function get_s(value){
    let tabel='';
    if(s_m=='titel'){
        
        for (let i = 0; i < new_pro_arr.length; i++) {
            
           if(new_pro_arr[i].titel.includes(value)){
            
            
               
                tabel+= `
                <tr>
              <td>${i}</td>
              <td>${new_pro_arr[i].titel}</td>
              <td>${new_pro_arr[i].count}</td>
              <td>${new_pro_arr[i].category}</td>
              <td>${new_pro_arr[i].price}</td>
              <td>${new_pro_arr[i].ads}</td>
              <td>${new_pro_arr[i].taxes}</td>
              <td>${new_pro_arr[i].discount}</td>
              <td><button onclick="add(${i})" id="add">ADD </button></td>
              <td><button onclick="sal(${i})" id="sale">sale </button></td>
              <td><button onclick=" ubdate(${i})" " id="ubdate">ubdate </button></td>
              <td><button onclick=" del(${i})" " id="del">delete </button></td>
              <td>${+new_pro_arr[index].price+ +new_pro_arr[index].ads+ +new_pro_arr[index].taxes - +new_pro_arr[index].discount}</td>
      
              </tr>
            `
         
            } 
           
            
        }

    }else { 
        for (let i = 0; i < new_pro_arr.length; i++) {
            
            if(new_pro_arr[i].category.includes(value)){
             
             
                
                 tabel+= `
                 <tr>
               <td>${i}</td>
               <td>${new_pro_arr[i].titel}</td>
               <td>${new_pro_arr[i].count}</td>
               <td>${new_pro_arr[i].category}</td>
               <td>${new_pro_arr[i].price}</td>
               <td>${new_pro_arr[i].ads}</td>
               <td>${new_pro_arr[i].taxes}</td>
               <td>${new_pro_arr[i].discount}</td>
               
               <td><button onclick="add(${i})" id="add">ADD </button></td>
               <td><button onclick="sal(${i})" id="sale">sale </button></td>
               <td><button onclick=" ubdate(${i})" " id="ubdate">ubdate </button></td>
               <td><button onclick=" del(${i})" " id="del">delete </button></td>
               <td>${+new_pro_arr[index].price+ +new_pro_arr[index].ads+ +new_pro_arr[index].taxes - +new_pro_arr[index].discount}</td>
      
               
               </tr>
             `
          
             } 
            
             
         }
    }
    document.getElementById('tb').innerHTML=  tabel
    
}